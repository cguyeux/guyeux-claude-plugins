---
name: bn-control
description: >-
  Find interventions (mutations / node fixings) that REPROGRAM a Boolean network toward a
  desired attractor or away from an undesired one, using Pint (reachability + cut sets),
  CABEAN (control of asynchronous Boolean networks), pyStableMotifs (target control via
  stable motifs) and ActoNet (abduction-based control of fixed points). Use for questions
  like "which perturbations induce/block EMT", "how to drive the model to the apoptotic
  state", "minimal interventions to reach a phenotype". Triggers: "control the network",
  "reprogramming", "which mutations reach state X", "block/induce EMT", "target control",
  "Pint reachability", "CABEAN", "stable motifs control", "minimal intervention".
---

# bn-control — reprogramming a Boolean model toward a target state

Prerequisite: know your target attractor/phenotype (use the `boolean-attractors` skill).
Most of these need the CoLoMoTo image (see `colomoto-run`); mpbn/pyStableMotifs are pip-ok.

## pyStableMotifs — target control from stable motifs (pip-installable)

```python
import pystablemotifs as sm
ar = sm.AttractorRepertoire.from_primes(primes)     # primes from a .bnet (biolqm-convert)
interventions = sm.drivers.knock_to_partial_state(
    {"ZEB1":1, "VIM":1}, primes, max_drivers=3)      # nodes to fix to reach a mesenchymal-like state
```

## Pint — reachability & mutations (goal-oriented)

```python
import pypint
model = pypint.load("model.bnet")                    # or an .an automata network
model.reachability(goal="Apoptosis=1")               # is it reachable?
model.oneshot_mutations_for_cut(goal="Proliferation=1")  # mutations that CUT reachability
```

## CABEAN — control of asynchronous Boolean networks

`cabean` python module: source/target attractor control (one-step, sequential, temporary).
Run inside the CoLoMoTo image. Good for "drive from attractor A to attractor B".

## ActoNet — abduction-based control of fixed points

`actonet` python module: infer perturbations enforcing a chosen fixed point.

**Interpretation.** A "control set" = a set of node fixings (equivalent to MaBoSS
mutations `NODE:ON/OFF`). Validate any control set back in MaBoSS: apply it as mutations
(maboss-mcp `maboss_run_simulation`) and check the resulting attractor
(`maboss_attractors`) matches the intended phenotype.
