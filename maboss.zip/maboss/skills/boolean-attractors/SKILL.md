---
name: boolean-attractors
description: >-
  Compute and label the ATTRACTORS (stable states / phenotypes) of a Boolean model with
  mpbn (Most Permissive), PyBoolNet or pyStableMotifs, starting from a MaBoSS .bnd/.cfg
  via `maboss.to_minibn`. Use this to identify the discrete states a model can settle in
  (e.g. epithelial / hybrid / mesenchymal, proliferative / apoptotic) which a single
  MaBoSS run only reports as node probabilities, not as named attractors. Also covers
  fixed points and trap spaces. Triggers: "find the attractors", "epithelial and
  mesenchymal states", "stable states / fixed points", "phenotypes of the model",
  "trap spaces", "which steady states", "mpbn", "pyboolnet attractors".
---

# boolean-attractors — from probabilities to named states

**Key idea.** MaBoSS gives P(node ON) at steady state (a mixture over attractors). To get
the *discrete states themselves* (phenotypes), compute the network's attractors. mpbn is
pip-installable (no Java) and reads a MaBoSS model via `maboss.to_minibn`.

## Ready-made: the maboss-mcp tool

The `maboss-mcp` server (this plugin's `mcp/` folder) exposes **`maboss_attractors`**:
give it `bnd`+`cfg` (optionally `output_nodes` = phenotype markers) and it returns each
attractor's active-node signature. Verified on the cancer_signaling sample -> 4 attractors
(proliferative BRAF/ERK/MAPK/Proliferation; apoptotic Apoptosis/EGFR; two immune ones).

## Direct (Python, in the maboss-mcp or colomoto image)

```python
import maboss, mpbn
sim = maboss.load("model.bnd", "model.cfg")
bn  = maboss.to_minibn(sim)                 # colomoto minibn, pure Python
mbn = mpbn.MPBooleanNetwork(bn)
for a in mbn.attractors():                  # a: {node: 0 | 1 | '*'}
    active = sorted(k for k,v in a.items() if v == 1)
    print(active)                           # <- label by signature (E vs M markers)
# reachable attractors from a specific initial state:
mbn.attractors(reachable_from={"BMP":0, "TGFB_L":0, "GF":0})
```
`'*'` = free/oscillating node. **Label each attractor** by its markers: epithelial =
Ecad/miR200/TightJunc ON & ZEB/SNAI/VIM OFF; mesenchymal = the reverse; hybrid = mixed.

## PyBoolNet (fixed points, trap spaces, exact async attractors)

```python
import pyboolnet.file_exchange as fe, pyboolnet.trap_spaces as ts
primes = fe.bnet2primes(open("model.bnet").read())   # need a .bnet (see biolqm-convert)
mints  = ts.compute_trap_spaces(primes, "min")        # minimal trap spaces ~ attractors
```

## pyStableMotifs (attractors + control handles)

```python
import pystablemotifs as sm
ar = sm.AttractorRepertoire.from_primes(primes)
ar.summary()                                          # attractors + their stable motifs
```
Stable motifs feed the `bn-control` skill (which interventions switch attractor).

**Pitfall.** If ALL attractors are trivial/identical regardless of inputs, suspect a
degenerate `.bnd` (frozen nodes) -> fix it first with the `biolqm-convert` skill.
